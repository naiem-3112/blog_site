<link rel="stylesheet" href="font-awesome-4.5.0/css/font-awesome.css">	
<link rel="stylesheet" href="css/nivo-slider.css" type="text/css" media="screen" />
<link rel="stylesheet" href="style.css">
<style>
/*default*/
/*.headersection {A56E0A
  background:none 0 0 repeat scroll #CA932F;}
  .icon a {
  background:none 0 0 repeat scroll #A56E0A;}

green

.headersection {
  background:none 0 0 repeat scroll #FF0000;}
.icon a {
  background:none 0 0 repeat scroll rgba(255, 255, 153, 0.533);}*/


</style>