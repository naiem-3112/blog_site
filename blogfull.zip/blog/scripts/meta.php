<?php 
	if(isset($_GET['pageid'])){
		$pageid = $_GET['pageid'];
		$sql ="SELECT * FROM tbl_page WHERE id = '$pageid'";
		$get = $db->select($sql);
		if($get){
			while($result = $get->fetch_assoc()){ ?>
		<title><?php echo $result['pagename']; ?> || <?php echo TITLE; ?></title>

		<?php } } }

		elseif(isset($_GET['id'])){
		$postid = $_GET['id'];
		$sql ="SELECT * FROM tbl_post WHERE id = '$postid'";
		$get = $db->select($sql);
		if($get){
			while($result = $get->fetch_assoc()){ ?>
		<title><?php echo $result['title']; ?> || <?php echo TITLE; ?></title>

		<?php } } }

		elseif(isset($_GET['category'])){
		$catid = $_GET['category'];
		$sql ="SELECT * FROM tbl_category WHERE id = '$catid'";
		$get = $db->select($sql);
		if($get){
			while($result = $get->fetch_assoc()){ ?>
		<title><?php echo $result['name']; ?> || <?php echo TITLE; ?></title>

		<?php } } }



		else{ ?>
		<title><?php echo $fm->title(); ?> || <?php echo TITLE; ?></title>

			<?php } ?>

	 
	
	<meta name="language" content="English">
	<meta name="description" content="It is a website about education">
	<meta name="keywords" content="blog,cms blog">
	<meta name="author" content="Delowar">